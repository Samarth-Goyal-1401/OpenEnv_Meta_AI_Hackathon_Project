from typing import List
from context_router.models import CacheObservation

def grader_easy(trajectory: List[CacheObservation]) -> float:
    """
    Evaluates the 'easy' task trajectory.
    Returns a score between 0.0 and 1.0.
    """
    try:
        _ = trajectory  # Will use in Phase B
        return 0.5
    except Exception:
        return 0.0
